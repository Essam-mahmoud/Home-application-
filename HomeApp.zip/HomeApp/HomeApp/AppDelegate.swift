//
//  AppDelegate.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 9/27/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var coredata = CoreDataStack()
    


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        // make vontext to traete with core data
        let context1 = coredata.persistentContainer.viewContext
        
        // make a tab bar and then enter to the first page on it and access the tablr view 
        let tabBarCon = self.window?.rootViewController as! UITabBarController
        let homeListnavigatonVC = tabBarCon.viewControllers?[0] as! UINavigationController
        let homeListVC = homeListnavigatonVC.topViewController as! HomeListViewController
        homeListVC.context = context1
        let summaryNavigationVC = tabBarCon.viewControllers?[1] as! UINavigationController
        let SummaryVC = summaryNavigationVC.topViewController as! SummaryTableViewController
        SummaryVC.context = context1
        // Override point for customization after application launch.
        //deleteRecords()
        checkDataStorage()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        coredata.saveContext()
    }

    func checkDataStorage(){
        let request : NSFetchRequest<Home> = Home.fetchRequest()
        let context = coredata.persistentContainer.viewContext

        do{
            let homecount = try context.count(for: request)
            if(homecount == 0) {
                uploadSamplesData()
            }
        }catch{
            
        }
    }
    // function to upload data from json file to coredata
    func uploadSamplesData(){
        let context = coredata.persistentContainer.viewContext
        let url = Bundle.main.url(forResource: "homes", withExtension: "json")
        let data = try? Data(contentsOf: url!)
        do{
            let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
            let jsonArray = jsonResult.value(forKey: "home") as! NSArray
            for json in jsonArray{
                let homedata = json as! [String: Any]
                guard let city = homedata["city"] else {
                    return
                }
                guard let price = homedata["price"] else {
                    return
                }
                guard let bed = homedata["bed"] else {
                    return
                }
                guard let bath = homedata["bath"] else {
                    return
                }
                guard let sqft = homedata["sqftt"] else {
                    return
                }
                var image : UIImage?
                if let currentImage = homedata["image"]{
                    let imagename = currentImage as! String
                    image = UIImage(named: imagename)
                }
                guard let homeCat = homedata["category"] else {
                    return
                }
                let homeType = (homeCat as! NSDictionary)["homeType"] as! String
                guard let homeSatus = homedata["status"] else {
                    return
                }
                let isForSale = (homeSatus as! NSDictionary)["isForSale"] as? Bool
                
                // save to core data
                let home = homeType.caseInsensitiveCompare("condo") == .orderedSame ? Condo(context: context) : SingleFamily(context: context)
                home.price = price as! Double
                home.bed = Int16(bed as! Int)
                home.bath = Int16(bath as! Int)
                home.sqft = Int32(sqft as! Int)
                home.image = NSData.init(data: UIImageJPEGRepresentation(image!, 1.0)!)
                home.homeType = homeType
                home.city = city as? String
                home.isForSale = isForSale!
                if let unitsPerBul = homedata["unitsPerBuilding"]{
                    (home as! Condo).unitsPerBuilding = Int16(unitsPerBul as! Int)
                }
                if let lotSize = homedata["lotsize"] {
                   (home as! SingleFamily).lotSize = Int16(lotSize as! Int)
                }
                if let saleHistories = homedata["saleHistory"]{
                    let saleHistoryDate = home.salehistory?.mutableCopy() as! NSMutableSet
                    for saleDstail in saleHistories as! NSArray{
                        let saleDate = saleDstail as![String: AnyObject]
                        let saleHistory = SaleHistory(context: context)
                        saleHistory.soldPrice = saleDate["soldPrice"] as! Double
                        let soldDateStr = saleDate["soldDate"] as! String
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        let soldDate = dateFormatter.date(from: soldDateStr)
                        saleHistory.soldDate = soldDate! as NSDate
                        saleHistoryDate.add(saleHistory)
                        home.addToSalehistory(saleHistoryDate)
                    }
                }
                
                
            }
            coredata.saveContext()
        }catch{
            
        }
    }
    
    func deleteRecords(){
        let context = coredata.persistentContainer.viewContext
        let homerequest : NSFetchRequest<Home> = Home.fetchRequest()
        let saleHistoryRequest : NSFetchRequest<SaleHistory> = SaleHistory.fetchRequest()
        var deleteRequest : NSBatchDeleteRequest?
        var deleteResult : NSPersistentStoreResult?
        do{
            deleteRequest = NSBatchDeleteRequest(fetchRequest: homerequest as! NSFetchRequest<NSFetchRequestResult>)
            deleteResult = try context.execute(deleteRequest!)
            deleteRequest = NSBatchDeleteRequest(fetchRequest: saleHistoryRequest as! NSFetchRequest<NSFetchRequestResult>)
            deleteResult = try context.execute(deleteRequest!)
            
        }catch{
            fatalError("faild to removing existing record")
        }
    }
}
    

