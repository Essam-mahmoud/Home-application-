//
//  Extension.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/3/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation
extension Double {
    var currentFormatter : String{
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        return formatter.string(from: NSNumber(value: self))!
    }
}
