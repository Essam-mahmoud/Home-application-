//
//  HomeListViewController.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/3/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
import CoreData

class HomeListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, FilterTableViewDelegate{
  
    


    @IBAction func SegmentedAction(_ sender: UISegmentedControl) {
        let selectedValue = sender.titleForSegment(at: sender.selectedSegmentIndex)
        isForSale = selectedValue == "For Sale" ? true : false
        LoadDate()
        
        
    }
    
    
    @IBOutlet weak var MyTableView: UITableView!
    @IBOutlet weak var segmentC: UISegmentedControl!
    var selectedHome : Home?
    var sortDescriptor = [NSSortDescriptor]()
    var searchFilter : NSPredicate?
    var request : NSFetchRequest<Home>?
    // to treate with database get information from home and put it in context
    weak var context : NSManagedObjectContext!{
        didSet{
            return home = Home(context: context)
        }
    }
    lazy var homes = [Home]()
    var isForSale : Bool = true
    var home: Home? = nil
    // function to update list when choose filter  from list filters
    func updateHomeList(filterBy: NSPredicate?, sortBy: NSSortDescriptor?) {
        if let filter = filterBy{
            searchFilter = filter
        }
        if let sort = sortBy{
            sortDescriptor.append(sort)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        MyTableView.dataSource = self
        MyTableView.delegate = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        request = Home.fetchRequest()
        LoadDate()
    }
    
    func LoadDate() {
        
        var predicates = [NSPredicate]()
        let statusPredicate = NSPredicate(format: "isForSale = %@", isForSale as CVarArg)
        predicates.append(statusPredicate)
        if let additionalPredicate = searchFilter {
            predicates.append(additionalPredicate)
        }
        let predicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: predicates)
        request?.predicate = predicate
        if sortDescriptor.count > 0 {
            request?.sortDescriptors = sortDescriptor
            
        }
        
        homes = home!.getHomesByStatus(request: request!, Con: context)
        MyTableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
            return homes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = MyTableView.dequeueReusableCell(withIdentifier: "HomeCell", for: indexPath) as! HomeCell
        let currentHome = homes[indexPath.row]
        cell.configureCell(home: currentHome)
        return cell
    }
    
    


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DetailS"{
            let selectedIndex = MyTableView.indexPathForSelectedRow
            selectedHome = homes[(selectedIndex?.row)!]
            let destinationVC = segue.destination as! SaleHistoryViewController
            destinationVC.home = selectedHome
            destinationVC.context = context
        } else if segue.identifier == "FilterS"{
            sortDescriptor = []
            searchFilter = nil
            let controller = segue.destination as! FilterTableViewController
            controller.delegate = self
            
            
        }
    }


}
