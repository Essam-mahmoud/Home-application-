//
//  HomeCell.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/3/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class HomeCell: UITableViewCell {

    @IBOutlet weak var CityLable: UILabel!
    @IBOutlet weak var CategoryLable: UILabel!
    @IBOutlet weak var SqFtLable: UILabel!
    @IBOutlet weak var BathLable: UILabel!
    @IBOutlet weak var BedLable: UILabel!
    @IBOutlet weak var PriceLable: UILabel!
    @IBOutlet weak var HomeImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    func configureCell(home: Home){
        CityLable.text = home.city
        CategoryLable.text = home.homeType
        BedLable.text = String(home.bed)
        SqFtLable.text = String(home.sqft)
        BathLable.text = String(home.bath)
        PriceLable.text = home.price.currentFormatter
        let image = UIImage(data: home.image! as Data)
        HomeImage.image = image
        HomeImage.layer.borderWidth = 1
        HomeImage.layer.cornerRadius = 4
        HomeImage.clipsToBounds = true
        
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
