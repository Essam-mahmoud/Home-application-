//
//  saleHistoryTableViewCell.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/8/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class saleHistoryTableViewCell: UITableViewCell {

    @IBOutlet weak var SoldDateLable: UILabel!
    @IBOutlet weak var soldPriceLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func configureCell(saleHistory : SaleHistory){
        SoldDateLable.text = saleHistory.soldDate?.toString
        soldPriceLable.text = saleHistory.soldPrice.currentFormatter
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
