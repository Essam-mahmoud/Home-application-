//
//  Home+CoreDataProperties.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 9/27/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//
//

import Foundation
import CoreData


extension Home {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Home> {
        return NSFetchRequest<Home>(entityName: "Home")
    }

    @NSManaged public var bath: Int16
    @NSManaged public var bed: Int16
    @NSManaged public var city: String?
    @NSManaged public var homeType: String?
    @NSManaged public var image: NSData?
    @NSManaged public var isForSale: Bool
    @NSManaged public var price: Double
    @NSManaged public var sqft: Int32
    @NSManaged public var salehistory: NSSet?

}

// MARK: Generated accessors for salehistory
extension Home {

    @objc(addSalehistoryObject:)
    @NSManaged public func addToSalehistory(_ value: SaleHistory)

    @objc(removeSalehistoryObject:)
    @NSManaged public func removeFromSalehistory(_ value: SaleHistory)

    @objc(addSalehistory:)
    @NSManaged public func addToSalehistory(_ values: NSSet)

    @objc(removeSalehistory:)
    @NSManaged public func removeFromSalehistory(_ values: NSSet)

}
