//
//  Home+CoreDataClass.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 9/27/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Home)
public class Home: NSManagedObject {
    
    var soldPredicate: NSPredicate = NSPredicate(format : "isForSale = false")
    let request : NSFetchRequest<Home> = Home.fetchRequest()
    
    func getHomesByStatus (request : NSFetchRequest<Home>, Con: NSManagedObjectContext)->[Home]{
        do{
            let homes = try Con.fetch(request)
            return homes
            
        }catch{
            fatalError("Error in  getting list of homes")
        }
    }
    
    internal func getTotalHomeCells(con: NSManagedObjectContext)-> String{
        request.predicate = soldPredicate
        request.resultType = .dictionaryResultType
        let sumExpressionDescription = NSExpressionDescription()
        sumExpressionDescription.name = "totalSales"
        sumExpressionDescription.expression = NSExpression(forFunction: "sum:", arguments: [NSExpression(forKeyPath: "price")])
        sumExpressionDescription.expressionResultType = .doubleAttributeType
        request.propertiesToFetch = [sumExpressionDescription]
        do{
            let results = try con.fetch(request as! NSFetchRequest<NSFetchRequestResult>) as! [NSDictionary]
            let dictionary = results.first!
            let totalSales = dictionary["totalSales"] as! Double
            return totalSales.currentFormatter
        }catch{
            fatalError("Error counting single family home sold")
        }
    }
    func getNumberCondoSold(con : NSManagedObjectContext)-> String{
        let typePredicate = NSPredicate(format : "homeType = 'Condo'")
        let predicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [soldPredicate,typePredicate])
        request.predicate = predicate
        var count :NSNumber!
        do{
            let result = try con.fetch(request as! NSFetchRequestResult as! NSFetchRequest<NSFetchRequestResult>) as! [NSNumber]
            count = result.first
            
        }catch{
            fatalError("Error counting condo home sold")
        }
        return count.stringValue
    }
    func getNumberSFHomeSold(con: NSManagedObjectContext)->String{
        let typePredicate = NSPredicate(format : "homeType = 'Single Family'")
        let predicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [soldPredicate,typePredicate])
        request.predicate = predicate
        do{
            let count = try con.count(for: request)
            if count != NSNotFound{
                return String(count)
            }else{
                fatalError("Error counting single family home sold")
            }
        }catch{
            fatalError("Error counting single family home sold")
        }

    }
    
    
    func getHomepriceSold(priceType: String , con: NSManagedObjectContext)->String{
        request.predicate = soldPredicate
        request.resultType = .dictionaryResultType
        let sumExpressionDescription = NSExpressionDescription()
        sumExpressionDescription.name = priceType
        sumExpressionDescription.expression = NSExpression(forFunction: "\(priceType)", arguments: [NSExpression(forKeyPath: "price")])
        sumExpressionDescription.expressionResultType = .doubleAttributeType
        request.propertiesToFetch = [sumExpressionDescription]
        do{
            let results = try con.fetch(request as! NSFetchRequest<NSFetchRequestResult>) as! [NSDictionary]
            let dictionary = results.first!
            let totalSales = dictionary[priceType] as! Double
            return totalSales.currentFormatter
        }catch{
            fatalError("Errot on geting price type home sales ")
        }
        
    }
    

    func getAVGPrice(homeType : String, con : NSManagedObjectContext)-> String{
        let typePredicate = NSPredicate(format : "homeType = %@")
        let predicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [soldPredicate,typePredicate])
        request.predicate = predicate
        request.resultType = .dictionaryResultType
        let sumExpressionDescription = NSExpressionDescription()
        sumExpressionDescription.name = homeType
        sumExpressionDescription.expression = NSExpression(forFunction: "average:", arguments: [NSExpression(forKeyPath: "price")])
        sumExpressionDescription.expressionResultType = .doubleAttributeType
        request.propertiesToFetch = [sumExpressionDescription]
        do{
            let results = try con.fetch(request as! NSFetchRequest<NSFetchRequestResult>) as! [NSDictionary]
            let dictionary = results.first!
            let totalSales = dictionary[homeType] as! Double
            return totalSales.currentFormatter
        }catch{
            fatalError("Errot on geting home type home sales ")
        }
    }
    
    
    
}
