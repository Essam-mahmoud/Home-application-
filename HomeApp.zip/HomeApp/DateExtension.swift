//
//  DateExtension.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/8/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation
extension NSDate{
    var toString : String{
        
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        return dateformatter.string(from: self as Date)
    }
}
