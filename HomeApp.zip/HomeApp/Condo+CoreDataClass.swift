//
//  Condo+CoreDataClass.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 9/27/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Condo)
public class Condo: Home {

}
