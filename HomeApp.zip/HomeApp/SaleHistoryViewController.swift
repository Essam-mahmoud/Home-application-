//
//  SaleHistoryViewController.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/3/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
import CoreData
class SaleHistoryViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
  
    

    @IBOutlet weak var saleTableView: UITableView!
    @IBOutlet weak var saleImageView: UIImageView!
    lazy var SoldHistory = [SaleHistory]()
    var home : Home?
    var context  : NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saleTableView.dataSource = self
        saleTableView.delegate = self
        loadSoldHistory()
        if let imageHome = home?.image{
            let image = UIImage(data: imageHome as Data)
            saleImageView.image = image
            saleImageView.layer.borderWidth = 1
            saleImageView.layer.cornerRadius = 4
        }
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SoldHistory.count
    }
    func loadSoldHistory(){
        let saleHistory = SaleHistory(context: context)
        SoldHistory = saleHistory.getSolsHistory(home: home!, context: context)
        saleTableView.reloadData()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = saleTableView.dequeueReusableCell(withIdentifier: "historyCell", for: indexPath) as! saleHistoryTableViewCell
        let saleHistory = SaleHistory(context: context)
        cell.configureCell(saleHistory: saleHistory)
        return cell
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }


}
