//
//  HomeType.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 10/21/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation
enum HomeType:String {
    case Condo = "Condo"
    case SingleFamily = "Single Family"
}
