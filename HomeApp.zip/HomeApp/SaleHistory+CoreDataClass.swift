//
//  SaleHistory+CoreDataClass.swift
//  HomeApp
//
//  Created by Essam Mahmoud fathy on 9/27/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//
//

import Foundation
import CoreData

@objc(SaleHistory)
public class SaleHistory: NSManagedObject {
    
    
    func getSolsHistory(home: Home, context: NSManagedObjectContext) -> [SaleHistory]{
        let soldHistoryRequest : NSFetchRequest<SaleHistory> = SaleHistory.fetchRequest()
        soldHistoryRequest.predicate = NSPredicate(format: "home = %@", home)
        do{
            let soldHistory = try context.fetch(soldHistoryRequest)
            return soldHistory
        }catch{
            fatalError("error in getting data")
        }
    }

}
